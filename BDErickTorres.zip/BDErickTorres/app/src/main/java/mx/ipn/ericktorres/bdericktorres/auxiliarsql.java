package mx.ipn.ericktorres.bdericktorres;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by Profesor on 08/02/2019.
 */

public class auxiliarsql extends SQLiteOpenHelper{

    String SQL_Table = "CREATE TABLE Reservacion (" + "_id INTEGER PRIMARY KEY AUTOINCREMENT" + "Nombre TEXT)";

    public auxiliarsql(Context context, String DBname, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, DBname, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(SQL_Table);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}

